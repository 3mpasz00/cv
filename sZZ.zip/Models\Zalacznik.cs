using System.ComponentModel.DataAnnotations;

namespace TaskManager.Models;

public class Zalacznik
{
    public int Id { get; set; }
    [Required] public string NazwaPliku { get; set; } = string.Empty;
    [Required] public string Sciezka { get; set; } = string.Empty;
    public DateTime Utworzono { get; set; } = DateTime.UtcNow;
    public int ZadanieId { get; set; }
    public Zadanie? Zadanie { get; set; }
}
