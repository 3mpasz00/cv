using System.ComponentModel.DataAnnotations;

namespace TaskManager.Models;

public class Projekt
{
    public int Id { get; set; }
    [Required, StringLength(120)] public string Nazwa { get; set; } = string.Empty;
    [StringLength(2000)] public string? Opis { get; set; }
    [DataType(DataType.Date)] public DateTime DataRozpoczecia { get; set; } = DateTime.Today;
    [DataType(DataType.Date)] public DateTime? Termin { get; set; }
    [Range(0, 100)] public int ProcentUkonczenia { get; set; }
    public string OwnerId { get; set; } = string.Empty;
    public ApplicationUser? Owner { get; set; }
    public ICollection<Zadanie> Zadania { get; set; } = new List<Zadanie>();
}
