using System.ComponentModel.DataAnnotations;

namespace TaskManager.Models;

public class Komentarz
{
    public int Id { get; set; }
    [Required, StringLength(1500)] public string Tresc { get; set; } = string.Empty;
    public DateTime Utworzono { get; set; } = DateTime.UtcNow;
    public int ZadanieId { get; set; }
    public Zadanie? Zadanie { get; set; }
    public string AutorId { get; set; } = string.Empty;
    public ApplicationUser? Autor { get; set; }
}
