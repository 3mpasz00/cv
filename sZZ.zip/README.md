# TaskManager

Aplikacja ASP.NET Core MVC do zarządzania projektami i zadaniami zespołu.

## Wymagania

- .NET SDK 8.0 lub nowszy.
- Dostęp do NuGet podczas pierwszego uruchomienia.

## Uruchomienie

1. Otwórz terminal w katalogu projektu.
2. Wykonaj `dotnet restore`.
3. Wykonaj `dotnet run`.
4. Otwórz adres wyświetlony przez aplikację, zwykle `https://localhost:xxxx`.

Przy pierwszym starcie tworzona jest lokalna baza `taskmanager.db` oraz role i konta testowe:

| Rola | Login | Hasło |
|---|---|---|
| Administrator | admin@taskmanager.local | Admin123! |
| Użytkownik | user@taskmanager.local | User123! |

> Przed wdrożeniem zmień te hasła albo usuń konta demonstracyjne z `Data/SeedData.cs`.

## Etapy budowy projektu

1. **Konfiguracja** — `Program.cs` rejestruje MVC, Identity, role oraz SQLite.
2. **Model danych** — folder `Models` definiuje użytkownika, projekt, zadanie, komentarz i załącznik.
3. **Dane** — `ApplicationDbContext` tworzy relacje, a `SeedData` inicjalizuje bazę i role.
4. **Autoryzacja** — Identity UI udostępnia rejestrację oraz logowanie; kontrolery ograniczają akcje rolami.
5. **Projekty i zadania** — kontrolery MVC obsługują tworzenie, edycję, szczegóły, komentarze oraz pliki.
6. **Administracja i raporty** — panel pokazuje wskaźniki, a raporty prezentują wykonanie według projektu.
7. **Wygląd** — wspólny układ i CSS tworzą prosty, responsywny interfejs.

## Struktura

- `Areas/Identity` — obszar dla wbudowanego interfejsu Identity.
- `Controllers` — logika stron aplikacji.
- `Models` — encje i typy domenowe.
- `Data` — kontekst SQLite i dane startowe.
- `Views` — widoki Razor.
- `wwwroot/uploads` — pliki dodane do zadań.

## Uwaga o migracjach

Projekt przy pierwszym uruchomieniu używa `EnsureCreatedAsync`, więc nie wymaga wygenerowanych migracji. Jeśli w przyszłości model będzie rozwijany na istniejącej bazie, przejdź na migracje EF Core: usuń bazę demonstracyjną, wykonaj `dotnet ef migrations add InitialCreate`, a następnie zamień `EnsureCreatedAsync` na `MigrateAsync`.
