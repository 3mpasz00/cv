using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using TaskManager.Data;
using TaskManager.Models;

namespace TaskManager.Controllers;

[Authorize]
public class ProjectsController(ApplicationDbContext context, UserManager<ApplicationUser> users) : Controller
{
    public async Task<IActionResult> Index() => View(await context.Projekty.Include(p => p.Owner).Include(p => p.Zadania).OrderByDescending(p => p.Id).ToListAsync());
    public async Task<IActionResult> Details(int id)
    {
        var project = await context.Projekty.Include(p => p.Owner).Include(p => p.Zadania).ThenInclude(z => z.PrzypisanyDo).FirstOrDefaultAsync(p => p.Id == id);
        return project is null ? NotFound() : View(project);
    }
    [Authorize(Roles = "Administrator,Manager")]
    public IActionResult Create() => View();
    [HttpPost, ValidateAntiForgeryToken, Authorize(Roles = "Administrator,Manager")]
    public async Task<IActionResult> Create(Projekt projekt)
    {
        if (!ModelState.IsValid) return View(projekt);
        projekt.OwnerId = users.GetUserId(User)!;
        context.Add(projekt); await context.SaveChangesAsync();
        return RedirectToAction(nameof(Index));
    }
    [Authorize(Roles = "Administrator,Manager")]
    public async Task<IActionResult> Edit(int id)
    {
        var project = await context.Projekty.FindAsync(id); return project is null ? NotFound() : View(project);
    }
    [HttpPost, ValidateAntiForgeryToken, Authorize(Roles = "Administrator,Manager")]
    public async Task<IActionResult> Edit(int id, Projekt projekt)
    {
        if (id != projekt.Id) return NotFound();
        var existing = await context.Projekty.FindAsync(id); if (existing is null) return NotFound();
        if (!ModelState.IsValid) return View(projekt);
        existing.Nazwa = projekt.Nazwa; existing.Opis = projekt.Opis; existing.DataRozpoczecia = projekt.DataRozpoczecia; existing.Termin = projekt.Termin; existing.ProcentUkonczenia = projekt.ProcentUkonczenia;
        await context.SaveChangesAsync(); return RedirectToAction(nameof(Details), new { id });
    }
    [HttpPost, ValidateAntiForgeryToken, Authorize(Roles = "Administrator")]
    public async Task<IActionResult> Delete(int id)
    {
        var project = await context.Projekty.FindAsync(id); if (project is not null) { context.Projekty.Remove(project); await context.SaveChangesAsync(); }
        return RedirectToAction(nameof(Index));
    }
}
