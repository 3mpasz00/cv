using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using TaskManager.Data;

namespace TaskManager.Controllers;

[Authorize(Roles = "Administrator")]
public class AdminController(ApplicationDbContext context) : Controller
{
    public async Task<IActionResult> Index()
    {
        ViewBag.Projekty = await context.Projekty.CountAsync();
        ViewBag.Zadania = await context.Zadania.CountAsync();
        ViewBag.Zakonczone = await context.Zadania.CountAsync(z => z.Status == TaskManager.Models.StatusZadania.Zakonczone);
        return View();
    }
}
