using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;
using TaskManager.Models;

namespace TaskManager.Data;

public class ApplicationDbContext(DbContextOptions<ApplicationDbContext> options) : IdentityDbContext<ApplicationUser>(options)
{
    public DbSet<Projekt> Projekty => Set<Projekt>();
    public DbSet<Zadanie> Zadania => Set<Zadanie>();
    public DbSet<Komentarz> Komentarze => Set<Komentarz>();
    public DbSet<Zalacznik> Zalaczniki => Set<Zalacznik>();

    protected override void OnModelCreating(ModelBuilder builder)
    {
        base.OnModelCreating(builder);
        builder.Entity<Projekt>().HasOne(p => p.Owner).WithMany(u => u.OwnedProjects)
            .HasForeignKey(p => p.OwnerId).OnDelete(DeleteBehavior.Restrict);
        builder.Entity<Zadanie>().HasOne(z => z.PrzypisanyDo).WithMany(u => u.AssignedTasks)
            .HasForeignKey(z => z.PrzypisanyDoId).OnDelete(DeleteBehavior.SetNull);
        builder.Entity<Komentarz>().HasOne(k => k.Autor).WithMany()
            .HasForeignKey(k => k.AutorId).OnDelete(DeleteBehavior.Restrict);
    }
}
