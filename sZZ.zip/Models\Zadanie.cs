using System.ComponentModel.DataAnnotations;

namespace TaskManager.Models;

public enum StatusZadania { Nowe, WTrakcie, Zablokowane, Zakonczone }
public enum Priorytet { Niski, Sredni, Wysoki, Krytyczny }

public class Zadanie
{
    public int Id { get; set; }
    [Required, StringLength(160)] public string Tytul { get; set; } = string.Empty;
    [StringLength(3000)] public string? Opis { get; set; }
    [DataType(DataType.Date)] public DateTime? Termin { get; set; }
    public StatusZadania Status { get; set; } = StatusZadania.Nowe;
    public Priorytet Priorytet { get; set; } = Priorytet.Sredni;
    public int ProjektId { get; set; }
    public Projekt? Projekt { get; set; }
    public string? PrzypisanyDoId { get; set; }
    public ApplicationUser? PrzypisanyDo { get; set; }
    public ICollection<Komentarz> Komentarze { get; set; } = new List<Komentarz>();
    public ICollection<Zalacznik> Zalaczniki { get; set; } = new List<Zalacznik>();
}
