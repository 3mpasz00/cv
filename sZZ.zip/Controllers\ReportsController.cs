using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using TaskManager.Data;
using TaskManager.Models;

namespace TaskManager.Controllers;

[Authorize]
public class ReportsController(ApplicationDbContext context) : Controller
{
    public async Task<IActionResult> Index()
    {
        var all = await context.Zadania.Include(z => z.Projekt).ToListAsync();
        ViewBag.Razem = all.Count;
        ViewBag.Zakonczone = all.Count(z => z.Status == StatusZadania.Zakonczone);
        ViewBag.PoTerminie = all.Count(z => z.Termin < DateTime.Today && z.Status != StatusZadania.Zakonczone);
        return View(all.GroupBy(z => z.Projekt?.Nazwa ?? "Bez projektu").Select(g => new ReportRow(g.Key, g.Count(), g.Count(z => z.Status == StatusZadania.Zakonczone))).ToList());
    }
}
public record ReportRow(string Projekt, int Wszystkie, int Zakonczone);
