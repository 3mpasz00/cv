using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using TaskManager.Models;

namespace TaskManager.Controllers;

[Authorize(Roles = "Administrator")]
public class UsersController(UserManager<ApplicationUser> users) : Controller
{
    public async Task<IActionResult> Index()
    {
        var result = new List<(ApplicationUser User, string Roles)>();
        foreach (var user in users.Users.OrderBy(u => u.Email)) result.Add((user, string.Join(", ", await users.GetRolesAsync(user))));
        return View(result);
    }
}
