using Microsoft.AspNetCore.Identity;
using System.ComponentModel.DataAnnotations;

namespace TaskManager.Models;

public class ApplicationUser : IdentityUser
{
    [StringLength(100)]
    public string? DisplayName { get; set; }
    public ICollection<Projekt> OwnedProjects { get; set; } = new List<Projekt>();
    public ICollection<Zadanie> AssignedTasks { get; set; } = new List<Zadanie>();
}
