using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using TaskManager.Data;
using TaskManager.Models;

namespace TaskManager.Controllers;

[Authorize]
public class TasksController(ApplicationDbContext context, UserManager<ApplicationUser> users, IWebHostEnvironment environment) : Controller
{
    private async Task PopulateListsAsync(Zadanie? task = null)
    {
        ViewBag.Projekty = new SelectList(await context.Projekty.OrderBy(p => p.Nazwa).ToListAsync(), "Id", "Nazwa", task?.ProjektId);
        ViewBag.Uzytkownicy = new SelectList(await users.Users.OrderBy(u => u.Email).ToListAsync(), "Id", "Email", task?.PrzypisanyDoId);
    }
    public async Task<IActionResult> Index(int? projectId, StatusZadania? status)
    {
        var query = context.Zadania.Include(z => z.Projekt).Include(z => z.PrzypisanyDo).AsQueryable();
        if (projectId.HasValue) query = query.Where(z => z.ProjektId == projectId);
        if (status.HasValue) query = query.Where(z => z.Status == status);
        ViewBag.ProjectId = projectId; ViewBag.Status = status;
        return View(await query.OrderBy(z => z.Termin).ToListAsync());
    }
    public async Task<IActionResult> Details(int id)
    {
        var task = await context.Zadania.Include(z => z.Projekt).Include(z => z.PrzypisanyDo)
            .Include(z => z.Komentarze).ThenInclude(k => k.Autor).Include(z => z.Zalaczniki).FirstOrDefaultAsync(z => z.Id == id);
        return task is null ? NotFound() : View(task);
    }
    [Authorize(Roles = "Administrator,Manager")]
    public async Task<IActionResult> Create(int? projectId)
    {
        await PopulateListsAsync(); return View(new Zadanie { ProjektId = projectId ?? 0 });
    }
    [HttpPost, ValidateAntiForgeryToken, Authorize(Roles = "Administrator,Manager")]
    public async Task<IActionResult> Create(Zadanie task)
    {
        if (!ModelState.IsValid) { await PopulateListsAsync(task); return View(task); }
        context.Zadania.Add(task); await context.SaveChangesAsync(); return RedirectToAction(nameof(Details), new { id = task.Id });
    }
    [Authorize(Roles = "Administrator,Manager")]
    public async Task<IActionResult> Edit(int id)
    {
        var task = await context.Zadania.FindAsync(id); if (task is null) return NotFound(); await PopulateListsAsync(task); return View(task);
    }
    [HttpPost, ValidateAntiForgeryToken, Authorize(Roles = "Administrator,Manager")]
    public async Task<IActionResult> Edit(int id, Zadanie task)
    {
        if (id != task.Id) return NotFound();
        if (!ModelState.IsValid) { await PopulateListsAsync(task); return View(task); }
        context.Update(task); await context.SaveChangesAsync(); return RedirectToAction(nameof(Details), new { id });
    }
    [HttpPost, ValidateAntiForgeryToken]
    public async Task<IActionResult> AddComment(int taskId, string tresc)
    {
        if (string.IsNullOrWhiteSpace(tresc)) return RedirectToAction(nameof(Details), new { id = taskId });
        context.Komentarze.Add(new Komentarz { ZadanieId = taskId, Tresc = tresc.Trim(), AutorId = users.GetUserId(User)! });
        await context.SaveChangesAsync(); return RedirectToAction(nameof(Details), new { id = taskId });
    }
    [HttpPost, ValidateAntiForgeryToken]
    public async Task<IActionResult> Upload(int taskId, IFormFile file)
    {
        if (file is { Length: > 0 })
        {
            var folder = Path.Combine(environment.WebRootPath, "uploads"); Directory.CreateDirectory(folder);
            var savedName = $"{Guid.NewGuid():N}{Path.GetExtension(file.FileName)}";
            await using var stream = System.IO.File.Create(Path.Combine(folder, savedName)); await file.CopyToAsync(stream);
            context.Zalaczniki.Add(new Zalacznik { ZadanieId = taskId, NazwaPliku = Path.GetFileName(file.FileName), Sciezka = "/uploads/" + savedName }); await context.SaveChangesAsync();
        }
        return RedirectToAction(nameof(Details), new { id = taskId });
    }
    [HttpPost, ValidateAntiForgeryToken, Authorize(Roles = "Administrator")]
    public async Task<IActionResult> Delete(int id)
    {
        var task = await context.Zadania.FindAsync(id); if (task is not null) { context.Zadania.Remove(task); await context.SaveChangesAsync(); }
        return RedirectToAction(nameof(Index));
    }
}
