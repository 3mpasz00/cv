// Miejsce na przyszłe funkcje interfejsu.
